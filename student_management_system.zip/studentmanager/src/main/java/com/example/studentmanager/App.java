package com.example.studentmanager;

import java.util.List;
import java.util.Scanner;

public class App 
{
    public static void main( String[] args )
    {
    	StudentDao studentDao = new StudentDao();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Add Student");
            System.out.println("2. Update Student");
            System.out.println("3. Delete Student");
            System.out.println("4. Get Student");
            System.out.println("5. Get All Students");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter age: ");
                    int age = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter course: ");
                    String course = scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.nextLine();

                    Student student = new Student();
                    student.setName(name);
                    student.setAge(age);
                    student.setCourse(course);
                    student.setEmail(email);

                    studentDao.saveStudent(student);
                    System.out.println("Student added successfully.");
                    break;

                case 2:
                    System.out.print("Enter student ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine(); // consume newline

                    Student updateStudent = studentDao.getStudent(updateId);
                    if (updateStudent != null) {
                        System.out.print("Enter new name: ");
                        updateStudent.setName(scanner.nextLine());
                        System.out.print("Enter new age: ");
                        updateStudent.setAge(scanner.nextInt());
                        scanner.nextLine(); // consume newline
                        System.out.print("Enter new course: ");
                        updateStudent.setCourse(scanner.nextLine());
                        System.out.print("Enter new email: ");
                        updateStudent.setEmail(scanner.nextLine());

                        studentDao.updateStudent(updateStudent);
                        System.out.println("Student updated successfully.");
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 3:
                    System.out.print("Enter student ID to delete: ");
                    int deleteId = scanner.nextInt();
                    studentDao.deleteStudent(deleteId);
                    System.out.println("Student deleted successfully.");
                    break;

                case 4:
                    System.out.print("Enter student ID to get: ");
                    int getId = scanner.nextInt();
                    Student getStudent = studentDao.getStudent(getId);
                    if (getStudent != null) {
                        System.out.println("ID: " + getStudent.getId());
                        System.out.println("Name: " + getStudent.getName());
                        System.out.println("Age: " + getStudent.getAge());
                        System.out.println("Course: " + getStudent.getCourse());
                        System.out.println("Email: " + getStudent.getEmail());
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 5:
                    List<Student> students = studentDao.getAllStudents();
                    for (Student s : students) {
                        System.out.println("ID: " + s.getId());
                        System.out.println("Name: " + s.getName());
                        System.out.println("Age: " + s.getAge());
                        System.out.println("Course: " + s.getCourse());
                        System.out.println("Email: " + s.getEmail());
                        System.out.println("-----------------------------");
                    }
                    break;

                case 6:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    }
